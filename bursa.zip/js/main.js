var api_url = "http://localhost/bursaotomotif/public/";



function register(){
	var email = $("#reg_email").val();
	var fullname = $("#reg_name").val();
	var password = $("#reg_pass").val();
	var phone = $("#reg_phone").val();
	var role = "customer";
	var password_confirmation = $("#reg_repass").val();
	
	if(password == password_confirmation){
		$.ajax({
			url:api_url+'auth/register',
			method:"POST",
			data:{
				email:email,
				role:role,
				password:password,
				password_confirmation:password_confirmation,
				fullname:fullname,
				phone:phone
			},
			beforeSend:function(){
				$("#reg_button").html("Mohon tunggu");
				$("#reg_button").css("opacity",".2");
				$("#reg_button").attr("disabled",false);
			},
			success:function(respon){
				console.log(respon.status);					
				if(respon.status=="success"){
					//$(".reg_form").fadeOut();
					/*
					$(".register").append('<input type="text" id="reg_otp"  />'+
					'<button class="butt-grey" id="reg_button" style="margin-top:30px"> Validasi </button>');
					$(".register h2").text("Validasi Nomor HP")
					*/
					$(".reg_form").fadeOut();
					$(".register h2").text("Silahkan periksa kotak SMS anda untuk verifikasi")
					//alert("")
					setTimeout(function(){
						location.reload();
					},6000)
				}else{
					console.log(respon.message)
				}
			}
		})
	}
}

function login(){
	var email_login = $("#log_email").val();
	var password_login = $("#log_pass").val();
	
	$.ajax({
		url:api_url+'auth/login',
		method:'POST',
		data:{
			email:email_login,
			password:password_login,
		},
		beforeSend:function(){
			$(".inp_group").hide();
			$(".log_email").append('<img src="../img/loading.gif" class="img-responsive" />')
		},
		success:function(respon){
			if(respon.status=="success"){
				localStorage.bm_login_status = "customer";
				localStorage.bm_token = respon.token;
				tokens = respon.token
				
				$.ajax({
					url: api_url+"profile",
					type:'GET',
					dataType:'json',
					crossDomain: true,
					headers:{
						'token':tokens
					},
					success:function(res){
						if(res.status=="success"){
							localStorage.bm_name = res.data.fullname;
							localStorage.bm_email = res.data.email;
							localStorage.bm_phone = res.data.phone;
							localStorage.bm_role = res.data.role;
							localStorage.bm_userid = res.data.id;
							location.reload();
						}else{
							alert("Kesalahan sistem")
						}
					}
				})
			}else{
				alert(respon.message)
			}
		}
	})
}

function edit_account(){
	var fullname = $("input[name=name]").val()
	var email = $("input[name=email]").val()
	var phone = $("input[name=phone]").val()
	var password = $("input[name=pass]").val()
	var photo = $("#imgInp").files;
	
	if(fullname!="" && email!="" && phone!=""){
		$.ajax({
			url:api_url+'user/'+ localStorage.bm_userid +'',
			method:"POST",
			headers:{
				token:localStorage.bm_token
			},
			data:{
				email:email,
				fullname:fullname,
				phone:phone,
				photo:photo,
			},
			beforeSend:function(){
				$(".save_btn").html("Mohon tunggu...")
				.css("opacity",".3")
				.attr("disabled",true)
			},
			dataType:'JSON',
			success:function(respon){
				//var respon = JSON.parse(res);
				//console.log(res)
				if(respon.status!="failed"){
					get_account();
				}else{
					if(respon.message=="Provided token is expired"){
						localStorage.bm_login_status="";
						localStorage.bm_name="";
						localStorage.bm_phone="";
						localStorage.bm_email="";
						location.reload();
					}else{
						$(".save_btn").html("Simpan")
						.css("opacity","1")
						.removeAttr("disabled")
					}
				}
			},
			error:function(err){
				//var er = JSON.parse(err);				
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				location.reload();
				localStorage.bm_token="";
				
			}
		})
	}
}

function get_account(){
	$.ajax({
		url: api_url+"profile",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				localStorage.bm_name = res.data.fullname;
				localStorage.bm_email = res.data.email;
				localStorage.bm_phone = res.data.phone;
				localStorage.bm_role = res.data.role;
				localStorage.bm_userid = res.data.id;
				location.reload();
			}else{
				alert("Kesalahan sistem")
			}
		}
	})
}

function get_all_cars(){
	$.ajax({
		url: api_url+"vehicle",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var data_car = res.data.data;
				for(var i=0;i < data_car.length;i++){
					$(".new_cars").append('<div class="mobil-info">'+
						'<div class="hover">'+
							'<button>Lihat Produk</button>'+
						'</div>'+
						'<div class="dislay">'+
							'<img src="'+ data_car[i].photo +'" width="100%">'+
						'</div>'+
						'<div class="detail">'+						
							'<p class="title"><strong>'+ data_car[i].name +' </strong></p>'+
							'<p><strong>Rp '+ addCommas(data_car[i].harga) +'</strong></p>'+
							'<span>'+ data_car[i].engine +'</span>'+
							'<span style="float:right">'+ data_car[i].brand.name +' </span>'+
						'</div>'+
					'</div>')
				}
				
				
			}else{
				alert("Kesalahan sistem")
			}
		},
		complete:function(){
			$(".mobil-info").hover(function(){
				var box_hover = $(this).find("div.hover");
				box_hover.animate({
					bottom:'0',
				},200);
			});
			
			$(".mobil-info").mouseleave(function(){
				var box_hover = $(this).find("div.hover");
				box_hover.animate({
					bottom:'-100%',
				},200);
			});
		}
	})
}

function get_inbox(){
	$.ajax({
		url: api_url+"inbox",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var inbox_item = res.data.data;
				for(var i=0;i < inbox_item.length;i++){
					$(".inbox").append(`
						<div class="belum-read">
			  <div class="pesan-head">
				<h3> `+ inbox_item[i].title +` </h3>
				<h4> ` + inbox_item[i].to.fullname + ` </h4>
			  </div>
			  <div class="pesan-isi">
				<p> `+ inbox_item[i].message +`</p>
			  </div>
			</div>`)
				}
				
				
			}else{
				alert("Kesalahan sistem")
			}
		}
	})
}

function get_transaction(){
	$.ajax({
		url: api_url+"transaction",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var trx = res.data.data;
				for(var i=0;i < trx.length;i++){
					$("#Riwayat").append(`
						<div class="isi-riwayat">
			<div class="riwayat">
			  <img src="img/1.jpg">
			  <h3> `+ trx[i].dealer.name +`  </h3>
			  <h4> `+ trx[i].dealer.address +` </h4>
			  <table>  
				<tr>
				  <td style="    width: 40%;">Nama</td>
				  <td>:</td> 
				  <td style="    width: 40%;">`+ trx[i].sales.fullname +`</td>
				</tr> 
				<tr>
				  <td style="    width: 40%;">Posisi </td>
				  <td>:</td> 
				  <td style="    width: 40%;">Sales </td>
				</tr> 
			  </table>
			</div>
		  <div class="clear"> </div>
		
		  <div class="detail-title">
		   <h4> Detil Kendaraan </h4>
		   <h4> Penawaran Dealer  </h4>
		  </div> 
		  
		   <table class="table-riwayat-kiri"> 
			<tr>
			  <td style="    width: 35%;">Area</td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">Jakarta</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Jenis Kendaraan </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">Mobil </td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Merek</td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.vehicle.brand.name +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Varian </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.vehicle.name +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Warna</td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.color +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Kuantiti </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.qty +` Unit </td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Cara Pembayaran </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.payment_method +`</td>
			</tr> 
		  </table> 
		  
		  <table class="table-riwayat-kiri"> 
			<tr>
			  <td style="    width: 35%;">Masa berlaku </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">Sampai `+ trx[i].expired_date +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">TDP </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.vehicle.brand.name +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Cicilan/bulan</td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].installment +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Ketersediaan Unit </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;"> Available </td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Promo</td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].promo +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Syarat Ketentuan </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].tnc +` </td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Keterangan Lain </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].description +` </td>
			</tr> 
		  </table>
		  
		  <div style="">
			<button class="edit_btn btn btn--primary btn-demo butt-red"> Pilih Penawaran </button>
		  </div>
		  
		  </div>
					`)
				}
				
				
			}else{
				alert("Kesalahan sistem")
			}
		}
	})
}

$(document).ready(function(){
	
	get_all_cars()
	if(localStorage.bm_login_status!="" && localStorage.bm_login_status!=undefined){
		if(localStorage.bm_login_status=="customer"){
			//console.log(tokens)
			
			

			$(".login-poss").html("<div style=' position:relative; background:white; height: 34px; padding: 4px 10px;  color:  #444;    border-radius: 18px;'><img src='http://s3.amazonaws.com/37assets/svn/765-default-avatar.png' width='28' style='   border-radius:  50%;' /><div style='margin-top:-27px;margin-left: 38px;'>  Hi, <a href='dashboard.html' style='color:#c51402; font-weight:bold; text-decoration:none; font-size: 12px;'>"+ localStorage.bm_name+"</a> <strong style='margin-left:20px; float:right' class='logout'>Keluar</strong></div></div>")
			$(".logout").hover(function(){
				$(this).css("cursor","pointer")
			})
			$(".logout").click(function(){
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				localStorage.bm_token="";
				location.reload();
			});
		}
	}else{
		if(document.URL.indexOf("dashboard.html") >= 0){
			window.location.href = "index.html";
		}
	}

	$("input[name=role]").change(function(){
		console.log($(this).val())
	})
	
	$("#reg_button").click(register);
	$("#log_button").click(login)
})