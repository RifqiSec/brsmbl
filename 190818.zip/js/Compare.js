/// <reference path="jquery-1.12.3.js" />
var list = JSON.parse(localStorage.bm_compare_item);
var compare_obj = {}
//localStorage.bm_compare_item=""

$(document).ready(function(){
	
	// Put the object into storage
	/* localStorage.setItem('bm_compare_item', JSON.stringify(list));

	// Retrieve the object from storage
	var retrievedObject = localStorage.getItem('bm_compare_item');

	console.log('retrievedObject: ', JSON.parse(retrievedObject)); */
	
	
	if(list.length > 0){
		console.log(JSON.parse(localStorage.bm_compare_item));
		/* var compare_get = localStorage.getItem('bm_compare_item')
		console.log(localStorage.bm_compare_item);*/
		var compare_cars = JSON.parse(localStorage.bm_compare_item)	;
		list = compare_cars;
		for(var i=0; i < compare_cars.length;i++){
			$(".comparePan").append('<div class="mobil-info relPos titleMargin" id="' + compare_cars[i].id + '" data-index="'+ i +'">'+
					'<div class="dislay ">'+			
						'<a class="selectedItemCloseBtn w3-closebtn">'+
							'<button class="selectedItemCloseBtn" style="background:#c51402; border:none; border-radius:4px; color:white; float:right; padding:6px 10px;" >x</button>'+
						'</a>'+
						'<img src="'+ compare_cars[i].image +'" width="100%">'+
					'</div>'+
					'<div class="detail">'+						
						'<p class="title" id="' + compare_cars[i].id + '"><strong>' + compare_cars[i].title + ' </strong></p>'+
					'</div>'+
				'</div>');
		}
		
		$(".selectedItemCloseBtn").each(function(){
			$(".selectedItemCloseBtn").click(function(){
				
				var this_index = $(this).parents("div.mobil-info").data("index");
				list.splice(this_index)
				localStorage.bm_compare_item = JSON.stringify(list)
				$(this).parents("div.mobil-info").remove();
				
				if(list.length!=0){
					console.log(localStorage.bm_compare_item)
				}else{
					console.log("Compare item is empty")
					$(".comparePan").html("<p class='empty-compare' style='margin-bottom:30px;'>Tidak ada produk yang dibandingkan</p>");
					$(".cmprBtn").hide()
				}
			})
		})
		
		
	}else{
		console.log("Compare item is empty")
		$(".comparePan").html("<p class='empty-compare' style='margin-bottom:30px;'>Tidak ada produk yang dibandingkan</p>");
		$(".cmprBtn").hide()
	}
	
	
	
    /* function to be executed when product is selected for comparision*/
	$(".comparePanle").hide();
	
    $(document).on('click', '.addToCompare', function () {
        $(".comparePanle").show();
        $(this).toggleClass("rotateBtn");
        $(this).parents(".selectProduct").toggleClass("selected");
        var productID = $(this).parents('.selectProduct').attr('data-title');

        var inArray = $.inArray(productID, list);
        if (inArray < 0) {
            if (list.length > 3	) {
                $("#WarningModal").show();
                $("#warningModalClose").click(function () {
                    $("#WarningModal").hide();
                });
                $(this).toggleClass("rotateBtn");
                $(this).parents(".selectProduct").toggleClass("selected");
                return;
            }

            if (list.length < 3) {
				
				$(".empty-compare").hide()
				$(".cmprBtn").show()
				
                var displayTitle = $(this).parents('.selectProduct').attr('data-id');
                var car_engine = $(this).parents('.selectProduct').attr('data-engine');
                var car_price = $(this).parents('.selectProduct').attr('data-price');

                var image = $(this).parents('.selectProduct').find("img").attr('src');
				
				
				compare_obj = {
					"id":productID,
					"title":displayTitle,
					"image":image
				}
				
                list.push(compare_obj);
				localStorage.setItem('bm_compare_item', JSON.stringify(list));
				
				$(".comparePan").append('<div class="mobil-info relPos titleMargin" id="' + productID + '">'+
					'<div class="dislay ">'+			
						'<a class="selectedItemCloseBtn w3-closebtn">'+
							'<button class="selectedItemCloseBtn" style="background:#c51402; border:none; border-radius:4px; color:white; float:right; padding:6px 10px;" >x</button>'+
						'</a>'+
						'<img src="'+ image +'" width="100%">'+
					'</div>'+
					'<div class="detail">'+						
						'<p class="title" id="' + productID + '"><strong>' + displayTitle + ' </strong></p>'+
					'</div>'+
				'</div>');
				
            }else{
				console.log("full")
			}
        } else {
            list.splice($.inArray(productID, list), 1);
            var prod = productID.replace(" ", "");
            $('#' + prod).remove();
            hideComparePanel();

        }
        if (list.length > 1) {
            $(".cmprBtn").addClass("active");
            $(".cmprBtn").removeAttr('disabled');
        } else {
            $(".cmprBtn").removeClass("active");
            $(".cmprBtn").attr('disabled', '');
        }

    });
	
    /*function to be executed when compare button is clicked*/
    $(document).on('click', '.cmprBtn', function () {
        if ($(".cmprBtn").hasClass("active")) {
            /* this is to print the  features list statically*/
            $(".contentPop").append('<div class="w3-col s3 m3 l3 compareItemParent relPos">' + '<ul class="product">' + '<li class=" relPos compHeader"><p class="w3-display-middle">Features</p></li>' + '<li>Title</li>' + '<li>Size</li>' + '<li>Weight</li>' + '<li class="cpu">Processor</li>' + '<li>Battery</li></ul>' + '</div>');

            for (var i = 0; i < list.length; i++) {
                /* this is to add the items to popup which are selected for comparision */
                product = $('.selectProduct[data-title="' + list[i] + '"]');
                var image = $('[data-title=' + list[i] + ']').find(".productImg").attr('src');
                var title = $('[data-title=' + list[i] + ']').attr('data-id');
                /*appending to div*/
                $(".contentPop").append('<div class="w3-col s3 m3 l3 compareItemParent relPos">' + '<ul class="product">' + '<li class="compHeader"><img src="' + image + '" class="compareThumb"></li>' + '<li>' + title + '</li>' + '<li>' + $(product).data('size') + '</li>' + '<li>' + $(product).data('weight') + '<li class="cpu">' + $(product).data('processor') + '</li>' + '<li>' + $(product).data('battery') + '</ul>' + '</div>');
            }
        }
        $(".modPos").show();
    });

    /* function to close the comparision popup */
    $(document).on('click', '.closeBtn', function () {
        $(".contentPop").empty();
        $(".comparePan").empty();
        $(".comparePanle").hide();
        $(".modPos").hide();
        $(".selectProduct").removeClass("selected");
        $(".cmprBtn").attr('disabled', '');
        list.length = 0;
        $(".rotateBtn").toggleClass("rotateBtn");
    });

    /*function to remove item from preview panel*/
    /* $(document).on('click', '.selectedItemCloseBtn', function () {

        var test = $(this).parent("div").siblings(".detail").find('p').attr('id');
        $('[data-title=' + test + ']').find(".addToCompare").click();
        hideComparePanel();
		if(list.length!=0){
			console.log(localStorage.bm_compare_item)
		}else{
			console.log("Compare item is empty")
			$(".comparePan").html("<p class='empty-compare' style='margin-bottom:30px;'>Tidak ada produk yang dibandingkan</p>");
			$(".cmprBtn").hide()
		}
		
    }); */

    function hideComparePanel() {
        if (!list.length) {
            $(".comparePan").empty();
            $(".comparePanle").hide();
        }
    }
});	