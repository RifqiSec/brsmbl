var api_url = "http://bursaotomotif-beta.com:8080/";



function register(){
	var email = $("#reg_email").val();
	var fullname = $("#reg_name").val();
	var password = $("#reg_pass").val();
	var phone = $("#reg_phone").val();
	var role = $("input[name=role]:checked").val();
	var password_confirmation = $("#reg_repass").val();
	
	if(password == password_confirmation){
		$.ajax({
			url:api_url+'auth/register',
			method:"POST",
			data:{
				email:email,
				role:role,
				password:password,
				password_confirmation:password_confirmation,
				fullname:fullname,
				phone:phone
			},
			beforeSend:function(){
				$("#reg_button").html("Mohon tunggu");
				$("#reg_button").css("opacity",".2");
				$("#reg_button").attr("disabled",false);
			},
			success:function(respon){
				console.log(respon.status);					
				if(respon.status=="success"){
					//$(".reg_form").fadeOut();
					/*
					$(".register").append('<input type="text" id="reg_otp"  />'+
					'<button class="butt-grey" id="reg_button" style="margin-top:30px"> Validasi </button>');
					$(".register h2").text("Validasi Nomor HP")
					*/
					$(".reg_form").fadeOut();
					$(".register h2").text("Silahkan periksa kotak SMS anda untuk verifikasi")
					//alert("")
					setTimeout(function(){
						location.reload();
					},2000)
				}else{
					console.log(respon.message)
				}
			}
		})
	}
}

function login(){
	var email_login = $("#log_email").val();
	var password_login = $("#log_pass").val();
	
	$.ajax({
		url:api_url+'auth/login',
		method:'POST',
		data:{
			email:email_login,
			password:password_login,
		},
		beforeSend:function(){
			$(".inp_group").hide();
			$(".log_email").append('<img src="img/loading.gif" class="img-responsive" />')
		},
		success:function(respon){
			if(respon.status=="success"){
				localStorage.bm_login_status = "customer";
				localStorage.bm_token = respon.token;
				tokens = respon.token
				
				$.ajax({
					url: api_url+"profile",
					type:'GET',
					dataType:'json',
					crossDomain: true,
					headers:{
						'token':tokens
					},
					success:function(res){
						if(res.status=="success"){
							localStorage.bm_name = res.data.fullname;
							localStorage.bm_email = res.data.email;
							localStorage.bm_phone = res.data.phone;
							localStorage.bm_role = res.data.role;
							//location.reload();
						}else{
							alert("Kesalahan sistem")
						}
					}
				})
			}else{
				alert(respon.message)
			}
		}
	})
}


$(document).ready(function(){
	if(localStorage.bm_login_status!="" || localStorage.bm_login_status!=undefined){
		if(localStorage.bm_login_status=="customer"){
			//console.log(tokens)
			
			

			$(".login-poss").html("<div style=' position:relative; background:white; height: 34px; padding: 4px 10px;  color:  #444;    border-radius: 18px;'><img src='http://s3.amazonaws.com/37assets/svn/765-default-avatar.png' width='28' style='   border-radius:  50%;' /><div style='margin-top:-27px;margin-left: 38px;'>  Hi, <span style='color:#c51402; font-weight:bold'>"+ localStorage.bm_name+"</span> <strong style='margin-left:20px; float:right' class='logout'>Keluar</strong></div></div>")
			$(".logout").hover(function(){
				$(this).css("cursor","pointer")
			})
			$(".logout").click(function(){
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				location.reload();
			});
		}
	}

	$("input[name=role]").change(function(){
		console.log($(this).val())
	})
	
	$("#reg_button").click(register);
	$("#log_button").click(login)
})