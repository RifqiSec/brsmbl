var api_url = "http://bursaotomotif-beta.com:8080/";
var fd = new FormData();


/* AUTH */

function register(){
	var email = $("#reg_email").val();
	var fullname = $("#reg_name").val();
	var password = $("#reg_pass").val();
	var phone = $("#reg_phone").val();
	var role = "customer";
	var password_confirmation = $("#reg_repass").val();
	
	if(password == password_confirmation){
		$.ajax({
			url:api_url+'auth/register',
			method:"POST",
			data:{
				email:email,
				role:role,
				password:password,
				password_confirmation:password_confirmation,
				fullname:fullname,
				phone:phone
			},
			beforeSend:function(){
				$("#reg_button").html("Mohon tunggu");
				$("#reg_button").css("opacity",".2");
				$("#reg_button").attr("disabled",false);
			},
			success:function(respon){
				console.log(respon.status);					
				if(respon.status=="success"){
					//$(".reg_form").fadeOut();
					/*
					$(".register").append('<input type="text" id="reg_otp"  />'+
					'<button class="butt-grey" id="reg_button" style="margin-top:30px"> Validasi </button>');
					$(".register h2").text("Validasi Nomor HP")
					*/
					$(".reg_form").fadeOut();
					$(".register h2").text("Silahkan periksa kotak SMS anda untuk verifikasi")
					//alert("")
					setTimeout(function(){
						location.reload();
					},6000)
				}else{
					console.log(respon.message)
				}
			}
		})
	}else{
		$("<div class='alert' style='color:red'>Password belum sesuai</div>").insertBefore("#reg_button");
		setTimeout(function(){
			$('.alert').fadeOut();
		},2000)
		
	}
}

function register_sales(){
	var email = $(".reg_email").val();
	var fullname = $(".reg_name").val();
	var password = $(".reg_pass").val();
	var phone = $(".reg_phone").val();
	var dealer_id = $(".reg_dealer").val();
	var nik = $(".reg_nik").val();
	var role = "sales";
	var password_confirmation = $(".reg_repass").val();
	if(email!="" && fullname!="" && password!="" && phone!="" && dealer_id!="" && role!="" &&  password_confirmation!=""){		
		if(password == password_confirmation){
			$.ajax({
				url:api_url+'auth/register',
				method:"POST",
				data:{
					email:email,
					role:role,
					password:password,
					password_confirmation:password_confirmation,
					fullname:fullname,
					phone:phone,
					dealer_id:dealer_id,
					nik:nik,
				},
				beforeSend:function(){
					$("#reg_sales_button").html("Mohon tunggu");
					$("#reg_sales_button").css("opacity",".2");
					$("#reg_sales_button").attr("disabled",true);
				},
				success:function(respon){
					console.log(respon.status);					
					if(respon.status=="success"){
						//$(".reg_form").fadeOut();
						/*
						$(".register").append('<input type="text" id="reg_otp"  />'+
						'<button class="butt-grey" id="reg_button" style="margin-top:30px"> Validasi </button>');
						$(".register h2").text("Validasi Nomor HP")
						*/
						$(".reg_form").fadeOut();
						$(".auth-page").html("Silahkan periksa email anda untuk aktivasi akun")
						//alert("")
						setTimeout(function(){
							location.reload();
						},6000)
					}else{
						$("#reg_sales_button").html("Daftar sebagai Sales");
						$("#reg_sales_button").css("opacity","1");
						$("#reg_sales_button").removeAttr("disabled");
					}
				}
			})
		}
	}else{
		$('<div class="alert" style="background:#fafafa; color:red; padding:10px; text-align:center;">Mohon lengkapi semua kolom</div>').insertBefore("#reg_sales_button");
		setTimeout(function(){
			$(".alert").fadeOut();
		},4000)
	}
}

function login(){
	var email_login = $(".log_email").val();
	var password_login = $(".log_pass").val();
	
	$.ajax({
		url:api_url+'auth/login',
		type:'POST',
		data:{
			email:email_login,
			password:password_login,
		},
		beforeSend:function(){
			$(".inp_group").hide();
			$(".login_form").append('<img src="img/loading.gif" style="margin:0 auto" class="img-responsive" width="100%" />')
			$(".login_form").css('text-align','center')
		},
		success:function(respon){
			if(respon.status=="success"){
				localStorage.bm_login_status = "customer";
				localStorage.bm_token = respon.token;
				tokens = respon.token
				
				$.ajax({
					url: api_url+"profile",
					type:'GET',
					dataType:'json',
					crossDomain: true,
					headers:{
						'token':tokens
					},
					success:function(res){
						if(res.status=="success"){
							localStorage.bm_name = res.data.fullname;
							localStorage.bm_email = res.data.email;
							localStorage.bm_phone = res.data.phone;
							localStorage.bm_role = res.data.role;
							localStorage.bm_login_status = res.data.role;
							localStorage.bm_userid = res.data.id;
							get_account()
							if(res.data.role=="customer"){
								//location.reload();
							}else if(res.data.role=="sales"){
								//window.location.href = "dashboard-sales.html";						
							}else{
								//window.location.href = "dashboard-merchant.html";
							}
						}else{
							alert("Kesalahan sistem")
						}
					}
				})
			}else{
				alert(respon.message)
			}
		}
	})
}

function edit_account(){
	var fullname = $("input[name=name]").val()
	var email = $("input[name=email]").val()
	var phone = $("input[name=phone]").val()
	var photo = $('#blah').attr("src");
	
	if(fullname!="" && email!="" && phone!=""){
		$.ajax({
			url:api_url+'user/'+ localStorage.bm_userid +'',
			method:"POST",
			headers:{
				token:localStorage.bm_token
			},
			data:{
				email:email,
				fullname:fullname,
				phone:phone,
				photo:photo,
			},
			beforeSend:function(){
				$(".save_btn").html("Mohon tunggu...")
				.css("opacity",".3")
				.attr("disabled",true)
			},
			dataType:'JSON',
			success:function(respon){
				//var respon = JSON.parse(res);
				//console.log(res)
				if(respon.status!="failed"){
					get_account();
					setTimeout(function(){
						if(localStorage.bm_role=="customer"){
							window.location.href="dashboard.html";
						}else if(localStorage.bm_role=="sales"){
							window.location.href="dashboard-sales.html";
						}else if(localStorage.bm_role=="dealer"){
							window.location.href="dashboard-merchant.html";
						}	
					},2500)
				}else{
					if(respon.message=="Provided token is expired"){
						localStorage.bm_login_status="";
						localStorage.bm_name="";
						localStorage.bm_phone="";
						localStorage.bm_email="";
						location.reload();
					}else{
						$(".save_btn").html("Simpan")
						.css("opacity","1")
						.removeAttr("disabled")
					}
				}
			},
			error:function(err){
				//var er = JSON.parse(err);				
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				location.reload();
				localStorage.bm_token="";
				
			}
		})
	}
}


/* DASHBOARD */

function get_account(){
	$.ajax({
		url: api_url+"profile",
		method:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				localStorage.bm_name = res.data.fullname;
				localStorage.bm_email = res.data.email;
				localStorage.bm_phone = res.data.phone;
				localStorage.bm_role = res.data.role;
				localStorage.bm_userid = res.data.id;
				localStorage.bm_token_balance = res.data.token;
				localStorage.bm_nik = res.data.nik;
				localStorage.bm_photo = res.data.photo;
				//location.reload();
				if(res.data.sales.length > 0){
					localStorage.bm_dealer_name = res.data.sales[0].name
					localStorage.bm_dealer_address = res.data.sales[0].address
					localStorage.bm_dealer_trademark = res.data.sales[0].trademark
					localStorage.bm_dealer_id = res.data.sales[0].id
					localStorage.bm_dealer_join = res.data.sales[0].created_at;
					localStorage.bm_dealer_city = res.data.sales[0].city_id;
					if(res.data.sales[0].pivot.is_active=="1"){
						localStorage.bm_dealer_sales_status="Aktif"
					}else{
						localStorage.bm_dealer_sales_status="Tidak Aktif"
					}
				}
				
				if(res.data.dealer.length > 0){
					localStorage.bm_dealer_name = res.data.dealer[0].name
					localStorage.bm_dealer_address = res.data.dealer[0].address
					localStorage.bm_dealer_trademark = res.data.dealer[0].trademark
					localStorage.bm_dealer_id = res.data.dealer[0].id
					localStorage.bm_dealer_join = res.data.dealer[0].created_at;
					localStorage.bm_dealer_city = res.data.dealer[0].city_id;
					localStorage.bm_dealer_type = res.data.dealer[0].company_type;
					if(res.data.sales[0].pivot.is_active=="1"){
						localStorage.bm_dealer_sales_status="Aktif"
					}else{
						localStorage.bm_dealer_sales_status="Tidak Aktif"
					}
				}
				
			}else{
				alert("Kesalahan sistem")
			}
		}
	})
}

function get_dealer_detail(Number){
	$.ajax({
			url: api_url+"dealer/show/"+ Number +"",
			type:'GET',
			dataType:'json',
			crossDomain: true,
			headers:{
				'token':localStorage.bm_token
			},
			success:function(res){
				if(res.status=="success"){
					localStorage.bm_dealer_name = res.data.name;
					localStorage.bm_dealer_type = res.data.company_type;
					localStorage.bm_dealer_trademark = res.data.trademark;
					localStorage.bm_dealer_address = res.data.address;
				}
			},
			complete:function(){
				
			}
	})
};

function get_all_cars(Number){
	$.ajax({
		url: api_url+"vehicle",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		enctype: 'multipart/form-data',
		success:function(res){
			if(res.status=="success"){
				var data_car = res.data.data;
				
				if(!Number){
					for(var i=0;i < data_car.length;i++){
					$(".new_cars").append('<div class="mobil-info selectProduct" data-title="'+ data_car[i].id +'" data-id="'+ data_car[i].name +'" data-size="4.9&quot;" data-weight="130 g" data-processor="'+ data_car[i].engine +'" data-battery="2300 mAH">'+
						'<div class="hover">'+
							'<button>Lihat Produk</button>'+
							'<button class="addToCompare">Bandingkan</button>'+
						'</div>'+
						'<div class="dislay">'+
							'<img src="'+ data_car[i].photo +'" width="100%">'+
						'</div>'+
						'<div class="detail">'+						
							'<p class="title"><strong>'+ data_car[i].name +' </strong></p>'+
							'<p><strong>Rp '+ addCommas(data_car[i].harga) +'</strong></p>'+
							'<span>'+ data_car[i].engine +'</span>'+
							'<span style="float:right">'+ data_car[i].brand.name +' </span>'+
						'</div>'+
					'</div>')
				}
				}else{
					for(var i=0;i < Number;i++){
						$(".new_cars").append('<div class="mobil-info selectProduct" data-title="'+ data_car[i].id +'" data-id="'+ data_car[i].name +'" data-size="4.9&quot;" data-weight="130 g" data-processor="'+ data_car[i].engine +'" data-battery="2300 mAH">'+
							'<div class="hover">'+
								'<button>Lihat Produk</button>'+
								'<button class="addToCompare">Bandingkan</button>'+
							'</div>'+
							'<div class="dislay">'+
								'<img src="'+ data_car[i].photo +'" width="100%">'+
							'</div>'+
							'<div class="detail">'+						
								'<p class="title"><strong>'+ data_car[i].name +' </strong></p>'+
								'<p><strong>Rp '+ addCommas(data_car[i].harga) +'</strong></p>'+
								'<span>'+ data_car[i].engine +'</span>'+
								'<span style="float:right">'+ data_car[i].brand.name +' </span>'+
							'</div>'+
						'</div>')
					}
				}
				
			}else{
				alert("Kesalahan sistem")
			}
		},
		complete:function(){
			$(".mobil-info").hover(function(){
				var box_hover = $(this).find("div.hover");
				box_hover.animate({
					bottom:'0',
				},200);
			});
			
			$(".mobil-info").mouseleave(function(){
				var box_hover = $(this).find("div.hover");
				box_hover.animate({
					bottom:'-100%',
				},200);
			});
		}
	})
}

function get_inbox(){
	$.ajax({
		url: api_url+"inbox",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var inbox_item = res.data.data;
				if(inbox_item.length > 0){
					for(var i=0;i < inbox_item.length;i++){
						$(".inbox").append(`
							<div class="belum-read">
				  <div class="pesan-head">
					<h3> `+ inbox_item[i].title +` </h3>
					<h4> ` + inbox_item[i].to.fullname + ` </h4>
				  </div>
				  <div class="pesan-isi">
					<p> `+ inbox_item[i].message +`</p>
				  </div>
				</div>`);
					}
				}else{
					$(".msg_num").hide()
					$(".inbox").append("Tidak ada pesan")
				}
			}else{
				alert("Kesalahan sistem")
			}
		}
	})
}

function get_transaction(){
	$.ajax({
		url: api_url+"transaction",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var trx = res.data.data;
				if(res.data.data.length > 0){
					for(var i=0;i < trx.length;i++){
						$("#Riwayat").append(`
							<div class="isi-riwayat">
				<div class="riwayat">
				  <img src="img/1.jpg">
				  <h3> `+ trx[i].dealer.name +`  </h3>
				  <h4> `+ trx[i].dealer.address +` </h4>
				  <table>  
					<tr>
					  <td style="    width: 40%;">Nama</td>
					  <td>:</td> 
					  <td style="    width: 40%;">`+ trx[i].sales.fullname +`</td>
					</tr> 
					<tr>
					  <td style="    width: 40%;">Posisi </td>
					  <td>:</td> 
					  <td style="    width: 40%;">Sales </td>
					</tr> 
				  </table>
				</div>
			  <div class="clear"> </div>
			
			  <div class="detail-title">
			   <h4> Detil Kendaraan </h4>
			   <h4> Penawaran Dealer  </h4>
			  </div> 
			  
			   <table class="table-riwayat-kiri"> 
				<tr>
				  <td style="    width: 35%;">Area</td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">Jakarta</td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Jenis Kendaraan </td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">Mobil </td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Merek</td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.vehicle.brand.name +`</td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Varian </td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.vehicle.name +`</td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Warna</td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.color +`</td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Kuantiti </td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.qty +` Unit </td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Cara Pembayaran </td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.payment_method +`</td>
				</tr> 
			  </table> 
			  
			  <table class="table-riwayat-kiri"> 
				<tr>
				  <td style="    width: 35%;">Masa berlaku </td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">Sampai `+ trx[i].expired_date +`</td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">TDP </td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.vehicle.brand.name +`</td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Cicilan/bulan</td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].installment +`</td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Ketersediaan Unit </td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;"> Available </td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Promo</td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].promo +`</td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Syarat Ketentuan </td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].tnc +` </td>
				</tr> 
				<tr>
				  <td style="    width: 35%;">Keterangan Lain </td>
				  <td>:</td> 
				  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].description +` </td>
				</tr> 
			  </table>
			  
			  <div style="">
				<button class="edit_btn btn btn--primary btn-demo butt-red"> Pilih Penawaran </button>
			  </div>
			  
			  </div>
						`)
					}
				}else{
					$("#Riwayat").append("<p>Belum ada transaksi</p>")
				}
			}else{
				alert("Kesalahan sistem")
			}
		}
	})
}

function get_token_history(){
	$.ajax({
		url: api_url+"token/history",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var trx = res.data.data;
				if(trx.length > 0){
					for(var i=0;i < trx.length; i++){
						$('.token_history').append(`<div class="pemakaian-token">
								<table class="table-riwayat-kiri"> 
									<tr>
									  <td style="    width: 35%;">Tanggal </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">`+ trx[0].date +`</td>
									</tr> 
									<tr>
									  <td style="    width: 35%;">Keterangan </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">Minta Penawaran Kendaraan Baru  </td>
									</tr>  
									<tr>
									  <td style="    width: 35%;">Nama Dealer  </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">
									  <td style="    width: 72%; padding-left: 5%;">`+ trx[0].dealer.name +` </td>
									</tr> 
									<tr>
									  <td style="    width: 35%;">Token  </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">`+ trx[0].usage +` token</td>
									</tr>  
							  </table>
							  <div class="clear"> </div>
							  <button class="edit_btn btn btn--primary btn-demo butt-red"> Lihat Detail </button> 
						  </div>`)
					}
				}else{
					$('.token_history').html("<div style='margin-bottom:30px;'>Anda belum pernah menggunakan token</div>")
				}				
			}
		},
		complete:function(){
			
		}
	})
}

function get_payment_token_history(){
	$.ajax({
		url: api_url+"payment/history",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var trx = res.data.data;
				if(trx.length > 0){
					for(var i=0;i < trx.length; i++){
						if(trx[i].status=="pending"){
							$(".payment_current").append(`<table class="table-riwayat-kiri confirm-`+ trx[i].id +`" style="    margin-top: 20px; width: 100%;padding-bottom: 10px;  border-bottom: 1px solid #dedede;"> 
						<tr>
						  <td style="    width: 20%;">Harga Token</td>
						  <td style="    width: 1%;">:</td> 
						  <td style="    width: 72%; padding-left: 2%; font-weight: bold; ">Rp `+ addCommas(trx[i].price) +`</td>
						</tr> 
						<tr>
						  <td style="    width: 20%;">Jumlah Token  </td>
						  <td style="    width: 1%;">:</td> 
						  <td style="    width: 72%; padding-left: 2%;">10 Token </td>
						</tr> 
						<tr>
						  <td style="    width: 20%;">Kode Promo</td>
						  <td style="    width: 1%;">:</td>  
						  <td style="    width: 72%; padding-left: 2%; font-weight: bold;">BOCOM12345</td>
						</tr> 
						<tr>
						  <td style="    width: 20%;">Bonus Token </td>
						  <td style="    width: 1%;">:</td> 
						  <td style="    width: 72%; padding-left: 2%;">2 Token </td>
						</tr>  
						<tr>
						  <td style="    width: 20%;">Metode Pembaran</td>
						  <td style="    width: 1%;">:</td> 
						  <td style="    width: 72%; padding-left: 2%;">BCA Virtual Account</td>
						</tr>  
					</table>  
					<div class="clear"></div>

					<h4 style="    font-size: 18px; margin: 15px 0px 5px;"> Panduan Pembayaran</h4>
					<p>1.  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galleymbled it to make a type specimen book. </p>
					<p>2.  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.</p>


					<div style="">
						<button class="edit_btn btn btn--primary btn-demo butt-red" style=" margin-top: 10px;"> Bayar Sekarang </button>
					</div>

				</div>`)
						}else{
							$(".payment_history").append(`<div class="transaksi history-`+ trx[i].id +`">
								<table class="table-transaksi-kiri"> 
									<tr>
									  <td style="    width: 35%;">Nomor Order </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].id +` </td>
									</tr> 
									<tr>
									  <td style="    width: 35%;">Tanggal </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">12 Mei 2018</td>
									</tr> 
									<tr>
									  <td style="    width: 35%;">Metode Pembayaran </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].payment_method +`</td>
									</tr>  
									<tr>
									  <td style="    width: 35%;">Status  </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">Sudah dibayar </td>
									</tr> 
									<tr>
									  <td style="    width: 35%;">Bonus  </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">2 Token   </td>
									</tr>  
									<tr>
									  <td style="    width: 35%;">Keterangan  </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;" class="berhasil">Berhasil   </td>
									</tr> 
							  </table> 
						  </div>`)
						}
					}
				}else{
					$(".payment_current").append("<p>Belum ada konfirmasi pembayaran</p>")
				}
			}else{
				if(res.message=="Provided token is expired."){
					logout();
				}
			}
		},
		error:function(er){
			logout();
		}
	})
}


function logout(){
	localStorage.bm_login_status="";
	localStorage.bm_name="";
	localStorage.bm_phone="";
	localStorage.bm_email="";
	localStorage.bm_token="";
	localStorage.bm_dealer_name = ""
	localStorage.bm_dealer_address = ""
	localStorage.bm_dealer_trademark = ""
	localStorage.bm_dealer_id = ""
	localStorage.bm_dealer_join = ""
	localStorage.bm_dealer_city = ""
	localStorage.bm_dealer_sales_status = ""
	location.reload();
}


/* AREA & GENERAL */
function get_city(name){
	if(!name){
		$.ajax({
			url: api_url+"city",
			type:'GET',
			dataType:'json',
			crossDomain: true,
			headers:{
				'token':localStorage.bm_token
			},
			success:function(res){
				if(res.status=="success"){
					for(var i=0; i < res.data.length; i++){
						$(".sel_city").append('<option value="'+ res.data[i].id +'">'+ res.data[i].name +'</option>');
						//$(".sel_city").select2()
					}
				}
			}
		})
	}
}

function get_brand(type){
	if(!name){
		$.ajax({
			url: api_url+"brand",
			type:'GET',
			dataType:'json',
			crossDomain: true,
			headers:{
				'token':localStorage.bm_token
			},
			success:function(res){
				if(res.status=="success"){
					for(var i=0; i < res.data.length; i++){
						$(".sel_brand").append('<option value="'+ res.data[i].id +'">'+ res.data[i].name +'</option>')
					}
				}
			}
		})
	}
}

function send_message(){
	
}

/* DEALER */
function get_salesman(){
	$.ajax({
		url:api_url+'/sales/',
		type:'GET',
		headers:{
			"token":localStorage.bm_token
		},
		success:function(res){
			$(".sales_list").html("")
			if(res.status =="success"){
				var sales_list = res.data.data;
				if(sales_list.length > 0){
					for(var i=0; i < sales_list.length; i++){
						$(".sales_list").append('<div class="isi-riwayat" style="margin-bottom: 20px;">'+
							   '<table class="table-riwayat-kiri " style="width: 58%;"> '+
								'<tr>'+
									'<td>'+
										'<img id="blah" align="left" src="img/ava.png"  alt="Gambar terlalu besar" title=""/>'+
									'</td>'+
									'<td style="padding-left:20px">'+
										'<table class="table-riwayat-kiri " style="width:auto;"> '+
											'<tr>'+
											  '<td style="    width: 100%;">Nama</td>'+
											  '<td>:</td> '+
											  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].fullname +'</td>'+
											'</tr> '+
											'<tr>'+
											  '<td style="    width: 100%;">No. Handphone </td>'+
											  '<td>:</td> '+
											  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].phone +' </td>'+
											'</tr> '+
											'<tr>'+
											  '<td style="    width: 100%;">Posisi</td>'+
											  '<td>:</td> '+
											  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].role +'</td>'+
											'</tr> '+
											'<tr>'+
											  '<td style="    width: 100%;">NIK </td>'+
											  '<td>:</td> '+
											  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].nik +' </td>'+	
											'</tr>  '+
										'</table>'+
									'</td>'+	
								'</tr>  '+
							  '</table>  '+

							  '<div class="clear"> </div>'+
							  '<div style=" margin-bottom: 20px;">'+
								'<button class="edit_btn btn btn--primary btn-demo butt-red grey-btn" style="width:auto !important;  background: #bbb; color: #6f6f6f;  margin-right: 5px;"> History </button>'+
								'<button class="edit_btn btn btn--primary btn-demo butt-red red-btn" style="width:auto !important;"> Hapus </button>'+
							  '</div>'+
						  '</div>'+
						'<div class="clear"> </div>')
					}
				}else{
					$(".sales_list").html("<div style='width:100%; text-align:center; padding-top:20%'><p>Belum ada sales terdaftar</p></div>")
				}
			}
		}
	})	
}

function get_pending_salesman(){
	$.ajax({
		url:api_url+'/sales/pending',
		type:'GET',
		headers:{
			"token":localStorage.bm_token
		},
		beforeSend:function(){
			$(".sales_pending_list").html("")
		},
		success:function(res){
			if(res.status =="success"){
				var sales_num = res.data;
				if(sales_num.length > 0){
					var sales_list = res.data[0].sales_pending;	
					for(var i=0; i < sales_list.length; i++){
						
						$(".sales_pending_list").append('<div class="isi-riwayat sales-'+ sales_list[i].id +'" style="margin-bottom: 20px;">'+
							   '<table class="table-riwayat-kiri " style="width: 58%;"> '+
								'<tr>'+
									'<td>'+
										'<img id="blah" align="left" src="img/ava.png"  alt="Gambar terlalu besar" title=""/>'+
									'</td>'+
									'<td style="padding-left:20px">'+
										'<table class="table-riwayat-kiri " style="width:auto;"> '+
											'<tr>'+
											  '<td style="    width: 100%;">Nama</td>'+
											  '<td>:</td> '+
											  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].fullname +'</td>'+
											'</tr> '+
											'<tr>'+
											  '<td style="    width: 100%;">No. Handphone </td>'+
											  '<td>:</td> '+
											  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].phone +' </td>'+
											'</tr> '+
											'<tr>'+
											  '<td style="    width: 100%;">Posisi</td>'+
											  '<td>:</td> '+
											  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].role +'</td>'+
											'</tr> '+
											'<tr>'+
											  '<td style="    width: 100%;">NIK </td>'+
											  '<td>:</td> '+
											  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].nik +' </td>'+	
											'</tr>  '+
										'</table>'+
									'</td>'+	
								'</tr>  '+
							  '</table>  '+

							  '<div class="clear"> </div>'+
							  '<div style=" margin-bottom: 20px;">'+
								'<button class="ignore_btn btn grey-btn btn--primary btn-demo butt-red" style="width:auto !important" data-sales="'+ sales_list[i].id +'" data-dealer="'+ sales_list[i].pivot.dealer_id +'"> Tolak </button>'+
								'<button class="approve_btn btn red-btn btn--primary btn-demo butt-red" style="width:auto !important; margin-left: 15px;" data-sales="'+ sales_list[i].id +'" data-dealer="'+ sales_list[i].pivot.dealer_id +'"> Terima </button>'+
							  '</div>'+
						  '</div>'+
						'<div class="clear"> </div>')					
					}
				}else{
					$(".sales_pending_list").hide()
					$(".tab-pending").hide()
					$(".tab-existing").addClass("active")
					$(".sales_list").show()
				}
			}
		},
		complete:function(){
			$(".approve_btn").each(function(){
				$(this).click(function(){
					var sales_pending_id = $(this).data("sales");
					var dealer_id = $(this).data("dealer");
					
					$.ajax({
						url:api_url+"sales/approve",
						type:'POST',
						headers:{
							'token':localStorage.bm_token
						},
						data:{
							sales_pending_id:sales_pending_id,
							dealer_id:dealer_id
						},
						success:function(rex){
							if(rex.status=="success"){
								$(".sales-"+ sales_pending_id +"").remove();
								get_salesman();
								get_pending_salesman()
							}
						}
					})
				})				
			})
		}
	})	
}

function get_products(){
	$.ajax({
		url: api_url+"dealer/vehicle/",
		type:'GET',
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var data_car = res.data.data;
				if(data_car.length > 0){
					for(var i=0;i < data_car.length;i++){
						$(".my_cars").append('<div class="mobil-info">'+
							'<div class="hover">'+
								'<button>Lihat Produk</button>'+
							'</div>'+
							'<div class="dislay">'+
								'<img src="'+ data_car[i].photo +'" width="100%">'+
							'</div>'+
							'<div class="detail">'+						
								'<p class="title"><strong>'+ data_car[i].name +' </strong></p>'+
								'<p><strong>Rp '+ addCommas(data_car[i].harga) +'</strong></p>'+
								'<span>'+ data_car[i].engine +'</span>'+
								'<span style="float:right">'+ data_car[i].seat +' seats</span>'+
							'</div>'+
						'</div>')
					}
				}else{
					$(".my_cars").html("<div class='add_car' style='width:100%; text-align:center; padding-top:20%'><p>Anda Belum tambahkan produk</p><button class='red-btn' style='width:40% !important;'>Tambah sekarang</button></div>")
				}
				
				
			}else{
				alert("Kesalahan sistem")
			}
		},
		complete:function(){
			$(".add_car").click(function(){
				$(".add_cars").show()
				$(this).hide()
				//get_brand()
			})
		}
	})
}



$(document).ready(function(){
	
	$(".header-logo").click(function(){
		window.location.href="index.html"
	});
	
	
	
	if(localStorage.bm_name!="" && localStorage.bm_name!=undefined){
		$("body").append(`<div class="compare-panel comparePanle">	
	<h3> Produk yang dibandingkan </h3>
	<div class="comparePan" style="display:flex;"></div><button class="cmprBtn" style="" disabled>Bandingkan</button></div>`)
		
		$(".name").html(localStorage.bm_name)
		$(".phone").html(localStorage.bm_phone)
		$(".email").html(localStorage.bm_email)
		$(".type").html(localStorage.bm_role)
		
		$(".token_balance").html(localStorage.bm_token_balance)
		$(".company_name").html(localStorage.bm_dealer_name)
		$(".company_id").html(localStorage.bm_dealer_id)
		$(".company_address").html(localStorage.bm_dealer_address)
		$(".company_trademark").html(localStorage.bm_dealer_trademark)
		$(".company_join").html(localStorage.bm_dealer_join)
		$(".company_sales_status").html(localStorage.bm_dealer_sales_status);
		
		$("input.name").val(localStorage.bm_name)
		$("input.phone").val(localStorage.bm_phone)
		$("input.email").val(localStorage.bm_email)
		$("input.company_name").val(localStorage.bm_dealer_name)
		
		if(localStorage.bm_role=="customer"){
			//console.log(tokens)
			get_all_cars(5)
			
			$(".login-poss").html('<div style="position:relative;background:white;height: 34px;width: 70%;padding: 4px 10px;color:  #444;border-radius: 18px;float:  right;"><img class="avatar" src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png" width="28" style="border-radius:  50%;float:  left;"><div style="margin-top: 4px;margin-left: 38px;text-align:  left;">  Hi, <a href="dashboard.html" style="color:#c51402; font-weight:bold; text-decoration:none; font-size: 12px;">'+ localStorage.bm_name+'</a> <strong style="margin-left:20px; padding-left:10px; border-left:1px solid grey;"><i class="fas fa-coins"></i> '+ localStorage.bm_token_balance +' Token</strong><strong style="margin-left:10px; padding-left:10px; border-left:1px solid grey;" class="compare_link"><i class="fas fa-balance-scale"></i> Bandingkan</strong><strong style="margin-left:20px; float:right" class="logout">Keluar</strong></div></div>')
			$(".logout").hover(function(){
				$(this).css("cursor","pointer")
			})
			$(".logout").click(function(){
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				localStorage.bm_token="";
				location.reload();
			});
			if(localStorage.bm_photo!=undefined && localStorage.bm_photo!="null"){
				$(".avatar").attr("src",localStorage.bm_photo)
			}
			
			$("input.company_name").hide();
			$("select.sel_city").remove();
			$("input.company_sales_nik").hide();
		}
		
		if(localStorage.bm_role=="sales"){
			$(".login-poss").html('<div style="position:relative;background:white;height: 34px;width: 70%;padding: 4px 10px;color:  #444;border-radius: 18px;float:  right;"><img class="avatar" src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png" width="28" style="border-radius:  50%;float:  left;"><div style="margin-top: 4px;margin-left: 38px;text-align:  left;">  Hi, <a href="dashboard-sales.html" style="color:#c51402; font-weight:bold; text-decoration:none; font-size: 12px;">'+ localStorage.bm_name+'</a> <strong style="margin-left:20px; padding-left:10px; border-left:1px solid grey;"><i class="fas fa-coins"></i> '+ localStorage.bm_token_balance +'</strong><strong style="margin-left:10px; padding-left:10px; border-left:1px solid grey;" class="compare_link"><i class="fas fa-balance-scale"></i> Bandingkan</strong><strong style="margin-left:20px; float:right" class="logout">Keluar</strong></div></div>')
			if(localStorage.bm_photo!=undefined && localStorage.bm_photo!="null"){
				$(".avatar").attr("src",localStorage.bm_photo)
			}
			
			$(".logout").hover(function(){
				$(this).css("cursor","pointer")
			})
			$(".logout").click(function(){
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				localStorage.bm_token="";
				location.reload();
			});
			
			
		}
		
		if(localStorage.bm_role=="dealer"){
			$(".login-poss").html('<div style="position:relative;background:white;height: 34px;width: 70%;padding: 4px 10px;color:  #444;border-radius: 18px;float:  right;"><img class="avatar" src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png" width="28" style="border-radius:  50%;float:  left;"><div style="margin-top: 4px;margin-left: 38px;text-align:  left;">  Hi, <a href="dashboard-merchant.html" style="color:#c51402; font-weight:bold; text-decoration:none; font-size: 12px;">'+ localStorage.bm_name+'</a> <strong style="margin-left:20px; padding-left:10px; border-left:1px solid grey;"><i class="fas fa-coins"></i> '+ localStorage.bm_token_balance +'</strong><strong style="margin-left:10px; padding-left:10px; border-left:1px solid grey;" class="compare_link"><i class="fas fa-balance-scale"></i> Bandingkan</strong><strong style="margin-left:20px; float:right" class="logout">Keluar</strong></div></div>')
			
			if(localStorage.bm_photo!=undefined && localStorage.bm_photo!="null"){
				$(".avatar").attr("src",localStorage.bm_photo)
			}
			
			$(".logout").hover(function(){
				$(this).css("cursor","pointer")
			})
			$(".logout").click(function(){
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				localStorage.bm_token="";
				location.reload();
			});
			
			
		}
	
		$(".compare-panel").mouseleave(function(){
			$(".compare-panel").hide()
		})
	}else{
		if(document.URL.indexOf("dashboard.html") >= 0){
			window.location.href = "index.html";
		}
		
		if(document.URL.indexOf("dashboard-sales.html") >= 0){
			window.location.href = "login.html";
		}
		
		if(document.URL.indexOf("dashboard-merchant.html") >= 0){
			window.location.href = "login.html";
		}
	}

	$("input[name=role]").change(function(){
		console.log($(this).val())
	})
	
	
	
	$(".compare_link").click(function(){
		$(".compare-panel").toggle();
	})
	$("#reg_button").click(register);
	$("#reg_sales_button").click(register_sales);
	$("#log_button").click(login)
	$(".login-btn").click(login)
})