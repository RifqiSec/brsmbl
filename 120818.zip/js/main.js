var api_url = "http://bursaotomotif-beta.com:8080/";
var fd = new FormData();


/* AUTH */

function register(){
	var email = $("#reg_email").val();
	var fullname = $("#reg_name").val();
	var password = $("#reg_pass").val();
	var phone = $("#reg_phone").val();
	var role = "customer";
	var password_confirmation = $("#reg_repass").val();
	
	if(password == password_confirmation){
		$.ajax({
			url:api_url+'auth/register',
			method:"POST",
			data:{
				email:email,
				role:role,
				password:password,
				password_confirmation:password_confirmation,
				fullname:fullname,
				phone:phone
			},
			beforeSend:function(){
				$("#reg_button").html("Mohon tunggu");
				$("#reg_button").css("opacity",".2");
				$("#reg_button").attr("disabled",false);
			},
			success:function(respon){
				console.log(respon.status);					
				if(respon.status=="success"){
					//$(".reg_form").fadeOut();
					/*
					$(".register").append('<input type="text" id="reg_otp"  />'+
					'<button class="butt-grey" id="reg_button" style="margin-top:30px"> Validasi </button>');
					$(".register h2").text("Validasi Nomor HP")
					*/
					$(".reg_form").fadeOut();
					$(".register h2").text("Silahkan periksa kotak SMS anda untuk verifikasi")
					//alert("")
					setTimeout(function(){
						location.reload();
					},6000)
				}else{
					console.log(respon.message)
				}
			}
		})
	}else{
		$("<div class='alert' style='color:red'>Password belum sesuai</div>").insertBefore("#reg_button");
		setTimeout(function(){
			$('.alert').fadeOut();
		},2000)
		
	}
}

function register_sales(){
	var email = $(".reg_email").val();
	var fullname = $(".reg_name").val();
	var password = $(".reg_pass").val();
	var phone = $(".reg_phone").val();
	var dealer_id = $(".reg_dealer").val();
	var nik = $(".reg_nik").val();
	var role = "sales";
	var password_confirmation = $(".reg_repass").val();
	if(email!="" && fullname!="" && password!="" && phone!="" && dealer_id!="" && role!="" &&  password_confirmation!=""){		
		if(password == password_confirmation){
			$.ajax({
				url:api_url+'auth/register',
				method:"POST",
				data:{
					email:email,
					role:role,
					password:password,
					password_confirmation:password_confirmation,
					fullname:fullname,
					phone:phone,
					dealer_id:dealer_id,
					nik:nik,
				},
				beforeSend:function(){
					$("#reg_sales_button").html("Mohon tunggu");
					$("#reg_sales_button").css("opacity",".2");
					$("#reg_sales_button").attr("disabled",true);
				},
				success:function(respon){
					console.log(respon.status);					
					if(respon.status=="success"){
						//$(".reg_form").fadeOut();
						/*
						$(".register").append('<input type="text" id="reg_otp"  />'+
						'<button class="butt-grey" id="reg_button" style="margin-top:30px"> Validasi </button>');
						$(".register h2").text("Validasi Nomor HP")
						*/
						$(".reg_form").fadeOut();
						$(".auth-page").html("Silahkan periksa kotak SMS anda untuk verifikasi")
						//alert("")
						setTimeout(function(){
							location.reload();
						},6000)
					}else{
						$("#reg_sales_button").html("Daftar sebagai Sales");
						$("#reg_sales_button").css("opacity","1");
						$("#reg_sales_button").removeAttr("disabled");
					}
				}
			})
		}
	}else{
		$('<div class="alert" style="background:#fafafa; color:red; padding:10px; text-align:center;">Mohon lengkapi semua kolom</div>').insertBefore("#reg_sales_button");
		setTimeout(function(){
			$(".alert").fadeOut();
		},4000)
	}
}

function login(){
	var email_login = $(".log_email").val();
	var password_login = $(".log_pass").val();
	
	$.ajax({
		url:api_url+'auth/login',
		type:'POST',
		data:{
			email:email_login,
			password:password_login,
		},
		beforeSend:function(){
			$(".inp_group").hide();
			$(".log_email").append('<img src="../img/loading.gif" class="img-responsive" />')
		},
		success:function(respon){
			if(respon.status=="success"){
				localStorage.bm_login_status = "customer";
				localStorage.bm_token = respon.token;
				tokens = respon.token
				
				$.ajax({
					url: api_url+"profile",
					type:'GET',
					dataType:'json',
					crossDomain: true,
					headers:{
						'token':tokens
					},
					success:function(res){
						if(res.status=="success"){
							localStorage.bm_name = res.data.fullname;
							localStorage.bm_email = res.data.email;
							localStorage.bm_phone = res.data.phone;
							localStorage.bm_role = res.data.role;
							localStorage.bm_login_status = res.data.role;
							localStorage.bm_userid = res.data.id;
							get_account()
							if(res.data.role=="customer"){
								location.reload();
							}else if(res.data.role=="sales"){
								window.location.href = "dashboard-sales.html";						
							}else{
								
								window.location.href = "dashboard-merchant.html";
							}
						}else{
							alert("Kesalahan sistem")
						}
					}
				})
			}else{
				alert(respon.message)
			}
		}
	})
}

function edit_account(){
	var fullname = $("input[name=name]").val()
	var email = $("input[name=email]").val()
	var phone = $("input[name=phone]").val()
	var password = $("input[name=pass]").val()
	var photo = 	$('#imgInp')[0].files[0];
	
	if(fullname!="" && email!="" && phone!=""){
		$.ajax({
			url:api_url+'user/'+ localStorage.bm_userid +'',
			method:"POST",
			headers:{
				token:localStorage.bm_token
			},
			data:{
				email:email,
				fullname:fullname,
				phone:phone,
				photo:photo,
			},
			beforeSend:function(){
				$(".save_btn").html("Mohon tunggu...")
				.css("opacity",".3")
				.attr("disabled",true)
			},
			dataType:'JSON',
			success:function(respon){
				//var respon = JSON.parse(res);
				//console.log(res)
				if(respon.status!="failed"){
					get_account();
				}else{
					if(respon.message=="Provided token is expired"){
						localStorage.bm_login_status="";
						localStorage.bm_name="";
						localStorage.bm_phone="";
						localStorage.bm_email="";
						location.reload();
					}else{
						$(".save_btn").html("Simpan")
						.css("opacity","1")
						.removeAttr("disabled")
					}
				}
			},
			error:function(err){
				//var er = JSON.parse(err);				
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				location.reload();
				localStorage.bm_token="";
				
			}
		})
	}
}


/* DASHBOARD */

function get_account(){
	$.ajax({
		url: api_url+"profile",
		method:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				localStorage.bm_name = res.data.fullname;
				localStorage.bm_email = res.data.email;
				localStorage.bm_phone = res.data.phone;
				localStorage.bm_role = res.data.role;
				localStorage.bm_userid = res.data.id;
				localStorage.bm_token_balance = res.data.token;
				localStorage.bm_nik = res.data.nik;
				location.reload();
			}else{
				alert("Kesalahan sistem")
			}
		}
	})
}

function get_all_cars(){
	$.ajax({
		url: api_url+"vehicle",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		enctype: 'multipart/form-data',
		success:function(res){
			if(res.status=="success"){
				var data_car = res.data.data;
				for(var i=0;i < data_car.length;i++){
					$(".new_cars").append('<div class="mobil-info">'+
						'<div class="hover">'+
							'<button>Lihat Produk</button>'+
						'</div>'+
						'<div class="dislay">'+
							'<img src="'+ data_car[i].photo +'" width="100%">'+
						'</div>'+
						'<div class="detail">'+						
							'<p class="title"><strong>'+ data_car[i].name +' </strong></p>'+
							'<p><strong>Rp '+ addCommas(data_car[i].harga) +'</strong></p>'+
							'<span>'+ data_car[i].engine +'</span>'+
							'<span style="float:right">'+ data_car[i].brand.name +' </span>'+
						'</div>'+
					'</div>')
				}
				
				
			}else{
				alert("Kesalahan sistem")
			}
		},
		complete:function(){
			$(".mobil-info").hover(function(){
				var box_hover = $(this).find("div.hover");
				box_hover.animate({
					bottom:'0',
				},200);
			});
			
			$(".mobil-info").mouseleave(function(){
				var box_hover = $(this).find("div.hover");
				box_hover.animate({
					bottom:'-100%',
				},200);
			});
		}
	})
}

function get_inbox(){
	$.ajax({
		url: api_url+"inbox",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var inbox_item = res.data.data;
				if(inbox_item.length > 0){
					for(var i=0;i < inbox_item.length;i++){
						$(".inbox").append(`
							<div class="belum-read">
				  <div class="pesan-head">
					<h3> `+ inbox_item[i].title +` </h3>
					<h4> ` + inbox_item[i].to.fullname + ` </h4>
				  </div>
				  <div class="pesan-isi">
					<p> `+ inbox_item[i].message +`</p>
				  </div>
				</div>`);
					}
				}else{
					$(".inbox").html("Tidak ada pesan")
				}
			}else{
				alert("Kesalahan sistem")
			}
		}
	})
}

function get_transaction(){
	$.ajax({
		url: api_url+"transaction",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var trx = res.data.data;
				for(var i=0;i < trx.length;i++){
					$("#Riwayat").append(`
						<div class="isi-riwayat">
			<div class="riwayat">
			  <img src="img/1.jpg">
			  <h3> `+ trx[i].dealer.name +`  </h3>
			  <h4> `+ trx[i].dealer.address +` </h4>
			  <table>  
				<tr>
				  <td style="    width: 40%;">Nama</td>
				  <td>:</td> 
				  <td style="    width: 40%;">`+ trx[i].sales.fullname +`</td>
				</tr> 
				<tr>
				  <td style="    width: 40%;">Posisi </td>
				  <td>:</td> 
				  <td style="    width: 40%;">Sales </td>
				</tr> 
			  </table>
			</div>
		  <div class="clear"> </div>
		
		  <div class="detail-title">
		   <h4> Detil Kendaraan </h4>
		   <h4> Penawaran Dealer  </h4>
		  </div> 
		  
		   <table class="table-riwayat-kiri"> 
			<tr>
			  <td style="    width: 35%;">Area</td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">Jakarta</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Jenis Kendaraan </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">Mobil </td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Merek</td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.vehicle.brand.name +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Varian </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.vehicle.name +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Warna</td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.color +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Kuantiti </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.qty +` Unit </td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Cara Pembayaran </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.payment_method +`</td>
			</tr> 
		  </table> 
		  
		  <table class="table-riwayat-kiri"> 
			<tr>
			  <td style="    width: 35%;">Masa berlaku </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">Sampai `+ trx[i].expired_date +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">TDP </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].request.vehicle.brand.name +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Cicilan/bulan</td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].installment +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Ketersediaan Unit </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;"> Available </td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Promo</td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].promo +`</td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Syarat Ketentuan </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].tnc +` </td>
			</tr> 
			<tr>
			  <td style="    width: 35%;">Keterangan Lain </td>
			  <td>:</td> 
			  <td style="    width: 72%; padding-left: 5%;">`+ trx[i].description +` </td>
			</tr> 
		  </table>
		  
		  <div style="">
			<button class="edit_btn btn btn--primary btn-demo butt-red"> Pilih Penawaran </button>
		  </div>
		  
		  </div>
					`)
				}
				
				
			}else{
				alert("Kesalahan sistem")
			}
		}
	})
}

function get_token_history(){
	$.ajax({
		url: api_url+"token/history",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		success:function(res){
			if(res.status=="success"){
				var trx = res.data.data;
				if(trx.length > 0){
					for(var i=0;i < trx.length; i++){
						$('.token_history').append(`<div class="pemakaian-token">
								<table class="table-riwayat-kiri"> 
									<tr>
									  <td style="    width: 35%;">Tanggal </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">`+ trx[0].date +`</td>
									</tr> 
									<tr>
									  <td style="    width: 35%;">Keterangan </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">Minta Penawaran Kendaraan Baru  </td>
									</tr>  
									<tr>
									  <td style="    width: 35%;">Nama Dealer  </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">
									  <td style="    width: 72%; padding-left: 5%;">`+ trx[0].dealer.name +` </td>
									</tr> 
									<tr>
									  <td style="    width: 35%;">Token  </td>
									  <td>:</td> 
									  <td style="    width: 72%; padding-left: 5%;">`+ trx[0].usage +` token</td>
									</tr>  
							  </table>
							  <div class="clear"> </div>
							  <button class="edit_btn btn btn--primary btn-demo butt-red"> Lihat Detail </button> 
						  </div>`)
					}
				}else{
					$('.token_history').html("<div style='margin-bottom:30px;'>Anda belum pernah menggunakan token</div>")
				}				
			}
		},
		complete:function(){
			
		}
	})
}

/* AREA & GENERAL */
function get_city(name){
	if(!name){
		$.ajax({
			url: api_url+"city",
			type:'GET',
			dataType:'json',
			crossDomain: true,
			headers:{
				'token':localStorage.bm_token
			},
			success:function(res){
				if(res.status=="success"){
					for(var i=0; i < res.data.length; i++){
						$(".sel_city").append('<option value="'+ res.data[i].id +'">'+ res.data[i].name +'</option>')
					}
				}
			}
		})
	}
}

function get_brand(type){
	if(!name){
		$.ajax({
			url: api_url+"brand",
			type:'GET',
			dataType:'json',
			crossDomain: true,
			headers:{
				'token':localStorage.bm_token
			},
			success:function(res){
				if(res.status=="success"){
					for(var i=0; i < res.data.length; i++){
						$(".sel_brand").append('<option value="'+ res.data[i].id +'">'+ res.data[i].name +'</option>')
					}
				}
			}
		})
	}
}


/* DEALER */
function get_salesman(){
	$.ajax({
		url:api_url+'/sales/',
		type:'GET',
		headers:{
			"token":localStorage.bm_token
		},
		success:function(res){
			if(res.status =="success"){
				var sales_list = res.data.data;
				if(sales_list.length > 0){
					for(var i=0; i < sales_list.length; i++){
						$(".sales_list").append('<div class="isi-riwayat" style="margin-bottom: 20px;">'+
							   '<table class="table-riwayat-kiri "> '+
								'<tr>'+
								  '<td style="    width: 35%;">Nama</td>'+
								  '<td>:</td> '+
								  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].fullname +'</td>'+
								'</tr> '+
								'<tr>'+
								  '<td style="    width: 35%;">Nomor Handphone </td>'+
								  '<td>:</td> '+
								  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].phone +' </td>'+
								'</tr> '+
								'<tr>'+
								  '<td style="    width: 35%;">Posisi</td>'+
								  '<td>:</td> '+
								  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].role +'</td>'+
								'</tr> '+
								'<tr>'+
								  '<td style="    width: 35%;">NIK </td>'+
								  '<td>:</td> '+
								  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].nik +' </td>'+
								'</tr>  '+
							  '</table>  '+

							  '<div class="clear"> </div>'+
							  '<div style=" margin-bottom: 20px;">'+
								'<button class="edit_btn btn btn--primary btn-demo butt-red" style="    background: #bbb; color: #6f6f6f;  margin-right: 5px;"> History </button>'+
								'<button class="edit_btn btn btn--primary btn-demo butt-red"> Hapus </button>'+
							  '</div>'+
						  '</div>'+
						'<div class="clear"> </div>')
					}
				}else{
					$(".sales_list").html("<div style='width:100%; text-align:center; padding-top:20%'><p>Belum ada sales terdaftar</p></div>")
				}
			}
		}
	})	
}
function get_pending_salesman(){
	$.ajax({
		url:api_url+'/sales/pending',
		type:'GET',
		headers:{
			"token":localStorage.bm_token
		},
		success:function(res){
			if(res.status =="success"){
				var sales_list = res.data[0].sales_pending;
				if(sales_list.length > 0){
					for(var i=0; i < sales_list.length; i++){
						$(".sales_pending_list").append('<div class="isi-riwayat sales-'+ sales_list[i].id +'" style="margin-bottom: 20px;">'+
							   '<table class="table-riwayat-kiri "> '+
								'<tr>'+
								  '<td style="    width: 35%;">Nama</td>'+
								  '<td>:</td> '+
								  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].fullname +'</td>'+
								'</tr> '+
								'<tr>'+
								  '<td style="    width: 35%;">Nomor Handphone </td>'+
								  '<td>:</td> '+
								  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].phone +' </td>'+
								'</tr> '+
								'<tr>'+
								  '<td style="    width: 35%;">Posisi</td>'+
								  '<td>:</td> '+
								  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].role +'</td>'+
								'</tr> '+
								'<tr>'+
								  '<td style="    width: 35%;">NIK </td>'+
								  '<td>:</td> '+
								  '<td style="    width: 72%; padding-left: 2%;">'+ sales_list[i].nik +' </td>'+
								'</tr>  '+
							  '</table>  '+

							  '<div class="clear"> </div>'+
							  '<div style=" margin-bottom: 20px;">'+
								
								'<button class="approve_btn btn red-btn btn--primary btn-demo butt-red" style="width:auto !important" data-sales="'+ sales_list[i].id +'" data-dealer="'+ sales_list[i].pivot.dealer_id +'"> Terima </button>'+
							  '</div>'+
						  '</div>'+
						'<div class="clear"> </div>')					
					}
				}else{
					$(".sales_pending_list").html("<div style='width:100%; text-align:center; padding-top:20%'><p>Belum ada sales terdaftar</p></div>")
				}
			}
		},
		complete:function(){
			$(".approve_btn").each(function(){
				$(this).click(function(){
					var sales_pending_id = $(this).data("sales");
					var dealer_id = $(this).data("dealer");
					
					$.ajax({
						url:api_url+"sales/approve",
						type:'POST',
						headers:{
							'token':localStorage.bm_token
						},
						data:{
							sales_pending_id:sales_pending_id,
							dealer_id:dealer_id
						},
						success:function(rex){
							if(rex.status=="success"){
								$(".sales-"+ sales_pending_id +"").remove();
								get_salesman()
							}
						}
					})
				})				
			})
		}
	})	
}

function get_products(){
	$.ajax({
		url: api_url+"dealer/vehicle/",
		type:'GET',
		dataType:'json',
		crossDomain: true,
		headers:{
			'token':localStorage.bm_token
		},
		enctype: 'multipart/form-data',
		success:function(res){
			if(res.status=="success"){
				var data_car = res.data.data;
				if(data_car.length > 0){
					for(var i=0;i < data_car.length;i++){
						$(".my_cars").append('<div class="mobil-info">'+
							'<div class="hover">'+
								'<button>Lihat Produk</button>'+
							'</div>'+
							'<div class="dislay">'+
								'<img src="'+ data_car[i].photo +'" width="100%">'+
							'</div>'+
							'<div class="detail">'+						
								'<p class="title"><strong>'+ data_car[i].name +' </strong></p>'+
								'<p><strong>Rp '+ addCommas(data_car[i].harga) +'</strong></p>'+
								'<span>'+ data_car[i].engine +'</span>'+
								'<span style="float:right">'+ data_car[i].brand.name +' </span>'+
							'</div>'+
						'</div>')
					}
				}else{
					$(".my_cars").html("<div class='add_car' style='width:100%; text-align:center; padding-top:20%'><p>Anda Belum tambahkan produk</p><button class='red-btn' style='width:40% !important;'>Tambah sekarang</button></div>")
				}
				
				
			}else{
				alert("Kesalahan sistem")
			}
		},
		complete:function(){
			$(".add_car").click(function(){
				$(".add_cars").show()
				$(this).hide()
				//get_brand()
			})
		}
	})
}



$(document).ready(function(){
	
	$(".header-logo").click(function(){
		window.location.href="index.html"
	})
	if(localStorage.bm_login_status!="" && localStorage.bm_login_status!=undefined){
		$(".name").html(localStorage.bm_name)
		$(".phone").html(localStorage.bm_phone)
		$(".email").html(localStorage.bm_email)
		$(".type").html(localStorage.bm_role)
		$(".token_balance").html(localStorage.bm_token_balance)
		
		
		if(localStorage.bm_role=="customer"){
			//console.log(tokens)
			get_all_cars()
			
			$(".login-poss").html('<div style="position:relative;background:white;height: 34px;width: 70%;padding: 4px 10px;color:  #444;border-radius: 18px;float:  right;"><img src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png" width="28" style="border-radius:  50%;float:  left;"><div style="margin-top: 4px;margin-left: 38px;text-align:  left;">  Hi, <a href="dashboard.html" style="color:#c51402; font-weight:bold; text-decoration:none; font-size: 12px;">'+ localStorage.bm_name+'</a> <strong style="margin-left:20px; padding-left:10px; border-left:1px solid grey;"><img src="http://www.iconninja.com/files/993/970/451/price-euro-finance-payment-currency-cash-coin-icon.svg" style="margin-right:6px" width="12" />'+ localStorage.bm_token_balance +' Token</strong><strong style="margin-left:10px; padding-left:10px; border-left:1px solid grey;"><img src="https://cdn.onlinewebfonts.com/svg/img_511201.png" style="margin-right:6px" width="19" /> Compare</strong><strong style="margin-left:20px; float:right" class="logout">Keluar</strong></div></div>')
			$(".logout").hover(function(){
				$(this).css("cursor","pointer")
			})
			$(".logout").click(function(){
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				localStorage.bm_token="";
				location.reload();
			});
		}
		
		if(localStorage.bm_role=="sales"){
			$(".login-poss").html('<div style="position:relative;background:white;height: 34px;width: 70%;padding: 4px 10px;color:  #444;border-radius: 18px;float:  right;"><img src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png" width="28" style="border-radius:  50%;float:  left;"><div style="margin-top: 4px;margin-left: 38px;text-align:  left;">  Hi, <a href="dashboard-sales.html" style="color:#c51402; font-weight:bold; text-decoration:none; font-size: 12px;">'+ localStorage.bm_name+'</a> <strong style="margin-left:20px; padding-left:10px; border-left:1px solid grey;"><img src="http://www.iconninja.com/files/993/970/451/price-euro-finance-payment-currency-cash-coin-icon.svg" style="margin-right:6px" width="12" />'+ localStorage.bm_token_balance +'</strong><strong style="margin-left:10px; padding-left:10px; border-left:1px solid grey;"><img src="https://cdn.onlinewebfonts.com/svg/img_511201.png" style="margin-right:6px" width="19" /> Compare</strong><strong style="margin-left:20px; float:right" class="logout">Keluar</strong></div></div>')
			
			
			$(".logout").hover(function(){
				$(this).css("cursor","pointer")
			})
			$(".logout").click(function(){
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				localStorage.bm_token="";
				location.reload();
			});
			
			
		}
		
		if(localStorage.bm_role=="dealer"){
			$(".login-poss").html('<div style="position:relative;background:white;height: 34px;width: 70%;padding: 4px 10px;color:  #444;border-radius: 18px;float:  right;"><img src="http://s3.amazonaws.com/37assets/svn/765-default-avatar.png" width="28" style="border-radius:  50%;float:  left;"><div style="margin-top: 4px;margin-left: 38px;text-align:  left;">  Hi, <a href="dashboard-merchant.html" style="color:#c51402; font-weight:bold; text-decoration:none; font-size: 12px;">'+ localStorage.bm_name+'</a> <strong style="margin-left:20px; padding-left:10px; border-left:1px solid grey;"><img src="http://www.iconninja.com/files/993/970/451/price-euro-finance-payment-currency-cash-coin-icon.svg" style="margin-right:6px" width="12" />'+ localStorage.bm_token_balance +'</strong><strong style="margin-left:10px; padding-left:10px; border-left:1px solid grey;"><img src="https://cdn.onlinewebfonts.com/svg/img_511201.png" style="margin-right:6px" width="19" /> Compare</strong><strong style="margin-left:20px; float:right" class="logout">Keluar</strong></div></div>')
			
			
			
			$(".logout").hover(function(){
				$(this).css("cursor","pointer")
			})
			$(".logout").click(function(){
				localStorage.bm_login_status="";
				localStorage.bm_name="";
				localStorage.bm_phone="";
				localStorage.bm_email="";
				localStorage.bm_token="";
				location.reload();
			});
			
			
		}
	
	}else{
		if(document.URL.indexOf("dashboard.html") >= 0){
			window.location.href = "index.html";
		}
		
		if(document.URL.indexOf("dashboard-sales.html") >= 0){
			window.location.href = "login.html";
		}
	}

	$("input[name=role]").change(function(){
		console.log($(this).val())
	})
	
	$("#reg_button").click(register);
	$("#reg_sales_button").click(register_sales);
	$("#log_button").click(login)
	$(".login-btn").click(login)
})